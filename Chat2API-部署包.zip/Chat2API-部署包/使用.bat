@echo off
setlocal
chcp 65001 >nul
title Chat2API Workbench
cd /d "%~dp0" || exit /b 1
set "PS=powershell.exe"
where pwsh >nul 2>nul && set "PS=pwsh"
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher.ps1" -Mode Start %*
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" echo [Chat2API] Failed. See the message above.
pause
exit /b %EXIT_CODE%
