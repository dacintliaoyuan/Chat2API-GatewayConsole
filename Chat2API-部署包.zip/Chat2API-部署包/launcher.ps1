﻿# Chat2API standalone launcher (Windows PowerShell 5.1 compatible).
# 部署.bat runs this file with -Mode Deploy (one-time setup).
# 使用.bat runs it with -Mode Start (the workbench menu).
# Keep this file UTF-8 with BOM so the Chinese messages survive cmd/PowerShell.
[CmdletBinding()]
param(
    [ValidateSet('Deploy', 'Start')]
    [string]$Mode,
    [ValidateSet('Menu', 'Start', 'Stop', 'Status', 'Login', 'Models', 'Logs')]
    [string]$Action = 'Menu',
    [switch]$CheckOnly
)

Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'

$root = $PSScriptRoot
$configPath = Join-Path $root 'config.txt'
$requirementsPath = Join-Path $root 'requirements.txt'
$venvDir = Join-Path $root '.venv'
$venvPython = Join-Path $venvDir 'Scripts\python.exe'
$serviceScript = Join-Path $root 'chat2api\chat2api.py'
$dataDir = Join-Path $root 'data'
$pidPath = Join-Path $dataDir 'chat2api.pid'
$controlTokenPath = Join-Path $dataDir 'admin-control-token'
$serviceLogPath = Join-Path $root 'chat2api\chat2api.log'
$consoleLogPath = Join-Path $dataDir 'chat2api.console.log'
$consoleErrPath = Join-Path $dataDir 'chat2api.console.err.log'

try {
    [Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
    $OutputEncoding = New-Object Text.UTF8Encoding($false)
} catch {
}

function Write-Step([string]$Message) {
    Write-Host ('[Chat2API] ' + $Message)
}

function Write-Warn([string]$Message) {
    Write-Host ('[Chat2API] 警告：' + $Message) -ForegroundColor Yellow
}

function Write-Fail([string]$Message) {
    Write-Host ('[Chat2API] 失败：' + $Message) -ForegroundColor Red
}

function Clear-Workbench {
    try { Clear-Host } catch { }
}

function Read-Config {
    $values = @{}
    if (-not (Test-Path -LiteralPath $configPath)) {
        return $values
    }
    foreach ($line in [IO.File]::ReadAllLines($configPath, [Text.Encoding]::UTF8)) {
        $trimmed = $line.Trim()
        if (-not $trimmed -or $trimmed.StartsWith('#')) {
            continue
        }
        $index = $trimmed.IndexOf('=')
        if ($index -lt 1) {
            continue
        }
        $key = $trimmed.Substring(0, $index).Trim().ToUpperInvariant()
        $value = $trimmed.Substring($index + 1).Trim()
        $values[$key] = $value
    }
    return $values
}

function Get-ConfigEntry($Config, [string]$Key, [string]$Default) {
    if ($Config.ContainsKey($Key) -and $Config[$Key]) {
        return [string]$Config[$Key]
    }
    return $Default
}

function Set-ConfigEntry([string]$Key, [string]$Value) {
    $lines = @()
    if (Test-Path -LiteralPath $configPath) {
        $lines = [IO.File]::ReadAllLines($configPath, [Text.Encoding]::UTF8)
    }
    $found = $false
    $output = @()
    foreach ($line in $lines) {
        if ($line -match ('^\s*' + [regex]::Escape($Key) + '\s*=')) {
            $output += ($Key + '=' + $Value)
            $found = $true
        } else {
            $output += $line
        }
    }
    if (-not $found) {
        $output += ($Key + '=' + $Value)
    }
    $text = ($output -join "`r`n") + "`r`n"
    [IO.File]::WriteAllText($configPath, $text, (New-Object Text.UTF8Encoding($false)))
}

function Resolve-UpstreamUrl([string]$Value) {
    $url = $Value.Trim().TrimEnd('/')
    $uri = $null
    if (-not [Uri]::TryCreate($url, [UriKind]::Absolute, [ref]$uri)) {
        throw '上游地址不是合法 URL，请写成 http://... 或 https://...'
    }
    if ($uri.Scheme -ne 'http' -and $uri.Scheme -ne 'https') {
        throw '上游地址必须以 http:// 或 https:// 开头。'
    }
    return $url
}

function Find-Python {
    $candidates = @(
        [pscustomobject]@{ Exe = 'py'; Prefix = @('-3') },
        [pscustomobject]@{ Exe = 'python'; Prefix = @() }
    )
    foreach ($candidate in $candidates) {
        if (-not (Get-Command $candidate.Exe -ErrorAction SilentlyContinue)) {
            continue
        }
        try {
            $version = & $candidate.Exe @($candidate.Prefix + @('-c', 'import sys; print(sys.version_info[0], sys.version_info[1])')) 2>$null
            if ($LASTEXITCODE -ne 0 -or -not $version) {
                continue
            }
            $parts = ([string]$version).Trim() -split '\s+'
            if ($parts.Count -ne 2) {
                continue
            }
            $major = [int]$parts[0]
            $minor = [int]$parts[1]
            if ($major -lt 3 -or ($major -eq 3 -and $minor -lt 10)) {
                continue
            }
            return [pscustomobject]@{
                Exe = $candidate.Exe
                Prefix = $candidate.Prefix
                Version = ($major.ToString() + '.' + $minor.ToString())
            }
        } catch {
            continue
        }
    }
    return $null
}

function Find-Edge {
    $programFiles = [Environment]::GetEnvironmentVariable('ProgramFiles')
    $programFilesX86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
    $localAppData = [Environment]::GetEnvironmentVariable('LOCALAPPDATA')
    $paths = @()
    if ($programFilesX86) {
        $paths += (Join-Path $programFilesX86 'Microsoft\Edge\Application\msedge.exe')
    }
    if ($programFiles) {
        $paths += (Join-Path $programFiles 'Microsoft\Edge\Application\msedge.exe')
    }
    if ($localAppData) {
        $paths += (Join-Path $localAppData 'Microsoft\Edge\Application\msedge.exe')
    }
    foreach ($path in $paths) {
        if (Test-Path -LiteralPath $path) {
            return $path
        }
    }
    return $null
}

function Test-PortInUse([int]$Port) {
    try {
        if (-not (Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue)) {
            return $false
        }
        $listener = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
        return ($null -ne $listener)
    } catch {
        return $false
    }
}

function Test-VenvDependencies {
    if (-not (Test-Path -LiteralPath $venvPython)) {
        return $false
    }
    try {
        & $venvPython -c 'import requests, playwright' 2>$null
        return ($LASTEXITCODE -eq 0)
    } catch {
        return $false
    }
}

function Get-LocalBaseUrl {
    $hostName = $bindHost
    if ($hostName -eq '0.0.0.0' -or $hostName -eq '::') {
        $hostName = '127.0.0.1'
    }
    if ($hostName -eq '::1') {
        $hostName = '[::1]'
    }
    return ('http://' + $hostName + ':' + $port)
}

function Read-ControlToken {
    if (-not (Test-Path -LiteralPath $controlTokenPath)) {
        return $null
    }
    try {
        $value = [IO.File]::ReadAllText($controlTokenPath).Trim()
        if ($value) { return $value }
        return $null
    } catch {
        return $null
    }
}

function Invoke-Admin {
    param(
        [ValidateSet('Get', 'Post')][string]$Method,
        [string]$Path,
        [int]$TimeoutSeconds = 5
    )
    $token = Read-ControlToken
    if (-not $token) {
        throw '控制令牌尚未生成；服务可能未启动。'
    }
    $uri = (Get-LocalBaseUrl) + $Path
    return Invoke-RestMethod -Method $Method -Uri $uri -Headers @{ 'X-Admin-Control' = $token } -TimeoutSec $TimeoutSeconds -ErrorAction Stop
}

function Get-ServiceProcess {
    $candidatePids = @()
    if (Test-Path -LiteralPath $pidPath) {
        $text = ''
        try {
            $text = [IO.File]::ReadAllText($pidPath).Trim()
        } catch {
            $text = ''
        }
        $recordedPid = 0
        if ([int]::TryParse($text, [ref]$recordedPid)) {
            $candidatePids += $recordedPid
        }
    }
    try {
        $listener = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
        if ($listener) {
            foreach ($item in @($listener)) {
                $candidatePids += [int]$item.OwningProcess
            }
        }
    } catch {
    }
    foreach ($servicePid in @($candidatePids | Select-Object -Unique)) {
        $process = Get-Process -Id $servicePid -ErrorAction SilentlyContinue
        if (-not $process) {
            continue
        }
        $cim = $null
        try {
            $cim = Get-CimInstance Win32_Process -Filter ('ProcessId=' + $servicePid) -ErrorAction SilentlyContinue
        } catch {
            continue
        }
        $commandLine = ''
        if ($cim) {
            $commandLine = [string]$cim.CommandLine
        }
        if (-not $commandLine -or -not $commandLine.ToLowerInvariant().Contains($serviceScript.ToLowerInvariant())) {
            continue
        }
        return [pscustomobject]@{ Id = $servicePid; Process = $process; CommandLine = $commandLine }
    }
    return $null
}

function Get-ServiceState {
    $process = Get-ServiceProcess
    $portInUse = Test-PortInUse $port
    if ($process) {
        if ($portInUse) { return 'Running' }
        return 'Starting'
    }
    if ($portInUse) { return 'PortConflict' }
    return 'Stopped'
}

function Get-ServiceStateLabel([string]$State) {
    switch ($State) {
        'Running' { return '运行中' }
        'Starting' { return '启动中' }
        'PortConflict' { return '端口被其他进程占用' }
        default { return '已停止' }
    }
}

function Get-AuthState {
    $state = Get-ServiceState
    if ($state -ne 'Running') {
        return [pscustomobject]@{ State = 'stopped'; Label = '服务已停止' }
    }
    try {
        $result = Invoke-Admin -Method Get -Path '/admin/auth/status'
        $label = [string]$result.label
        if (-not $label) {
            switch ([string]$result.state) {
                'valid' { $label = '认证有效' }
                'needs_login' { $label = '需要登录' }
                'logging_in' { $label = '登录中' }
                'login_failed' { $label = '登录失败' }
                default { $label = '状态未知' }
            }
        }
        return [pscustomobject]@{ State = [string]$result.state; Label = $label }
    } catch {
        return [pscustomobject]@{ State = 'unknown'; Label = '状态未知' }
    }
}

function Set-ServiceEnvironment {
    if ($clearProxy -eq '1') {
        $env:HTTP_PROXY = ''
        $env:HTTPS_PROXY = ''
        $env:ALL_PROXY = ''
        $env:http_proxy = ''
        $env:https_proxy = ''
        $env:all_proxy = ''
        $env:NO_PROXY = '*'
        $env:no_proxy = '*'
    }
    if ($allowedOrigins) {
        $env:CHAT2API_ALLOWED_ORIGINS = $allowedOrigins
    }
    if ($localApiKey) {
        $env:CHAT2API_LOCAL_API_KEY = $localApiKey
    }
    $env:CHAT2API_LAUNCH_SOURCE = 'bat'
    $env:PYTHONUTF8 = '1'
    $env:PYTHONIOENCODING = 'utf-8'
    $env:PYTHONUNBUFFERED = '1'
}

function Start-ServiceProcess {
    $state = Get-ServiceState
    if ($state -eq 'Running') {
        Write-Step '服务已在运行。'
        return $true
    }
    if ($state -eq 'Starting') {
        Write-Step '服务正在启动，请稍后刷新状态。'
        return $true
    }
    if ($state -eq 'PortConflict') {
        Write-Fail ('端口 ' + $port + ' 已被其他进程占用；不会启动。')
        return $false
    }
    if (-not (Test-Path -LiteralPath $venvPython)) {
        Write-Fail '尚未创建 .venv。请先双击 部署.bat 完成部署。'
        return $false
    }
    if (-not (Test-VenvDependencies)) {
        Write-Fail '依赖缺失。请先双击 部署.bat 完成部署。'
        return $false
    }

    New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
    Set-ServiceEnvironment
    $arguments = @(
        $serviceScript,
        '--base-url', $upstream,
        '--host', $bindHost,
        '--port', $port.ToString()
    )
    if ($useApiKey -eq '1') {
        $arguments += '--use-api-key'
    }
    Remove-Item -LiteralPath $consoleLogPath, $consoleErrPath -Force -ErrorAction SilentlyContinue
    try {
        $process = Start-Process -FilePath $venvPython -ArgumentList $arguments -WorkingDirectory $root -PassThru -RedirectStandardOutput $consoleLogPath -RedirectStandardError $consoleErrPath -WindowStyle Hidden
    } catch {
        Write-Fail ('启动失败：' + $_.Exception.Message)
        return $false
    }
    [IO.File]::WriteAllText($pidPath, $process.Id.ToString(), (New-Object Text.UTF8Encoding($false)))
    Write-Step ('已启动，等待就绪（PID ' + $process.Id + '）...')

    $ready = $false
    $deadline = (Get-Date).AddSeconds(30)
    while ((Get-Date) -lt $deadline) {
        if ($process.HasExited) {
            break
        }
        if (Test-PortInUse $port) {
            $ready = $true
            break
        }
        Start-Sleep -Milliseconds 500
    }
    if (-not $ready) {
        Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $pidPath -Force -ErrorAction SilentlyContinue
        Write-Fail '服务未能就绪；请查看日志。'
        foreach ($path in @($consoleErrPath, $consoleLogPath, $serviceLogPath)) {
            if (-not (Test-Path -LiteralPath $path)) {
                continue
            }
            $text = ''
            $stream = $null
            $reader = $null
            try {
                $stream = [IO.File]::Open($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
                $reader = New-Object IO.StreamReader($stream, [Text.Encoding]::UTF8)
                $text = $reader.ReadToEnd()
            } catch {
                $text = ''
            } finally {
                if ($reader) { $reader.Dispose() }
                if ($stream) { $stream.Dispose() }
            }
            if ($text.Trim()) {
                Write-Host ('--- ' + $path + ' ---')
                Write-Host $text
            }
        }
        return $false
    }
    Write-Step '服务已就绪。'
    return $true
}

function Stop-ServiceProcess {
    $serviceProcess = Get-ServiceProcess
    if (-not $serviceProcess) {
        Remove-Item -LiteralPath $pidPath -Force -ErrorAction SilentlyContinue
        Write-Step '没有由本工作台启动且仍在运行的服务。'
        return $true
    }
    $token = Read-ControlToken
    if ($token) {
        try {
            $null = Invoke-Admin -Method Post -Path '/admin/shutdown' -TimeoutSeconds 3
        } catch {
        }
    }
    $deadline = (Get-Date).AddSeconds(10)
    while ((Get-Date) -lt $deadline) {
        if (-not (Get-Process -Id $serviceProcess.Id -ErrorAction SilentlyContinue)) {
            break
        }
        Start-Sleep -Milliseconds 300
    }
    if (Get-Process -Id $serviceProcess.Id -ErrorAction SilentlyContinue) {
        Write-Step '优雅停止未完成，正在结束本工作台记录的进程...'
        Stop-Process -Id $serviceProcess.Id -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 500
    }
    Remove-Item -LiteralPath $pidPath -Force -ErrorAction SilentlyContinue
    if (Test-PortInUse $port) {
        Write-Fail ('端口 ' + $port + ' 仍被占用；请手动检查。')
        return $false
    }
    Write-Step '服务已停止。'
    return $true
}

function Invoke-WorkbenchLogin {
    $state = Get-ServiceState
    if ($state -eq 'PortConflict') {
        Write-Fail ('端口 ' + $port + ' 已被其他进程占用；不会启动登录。')
        return
    }
    $wasRunning = ($state -eq 'Running')
    if (-not $wasRunning) {
        if (-not (Start-ServiceProcess)) {
            return
        }
    }
    if (-not (Find-Edge)) {
        Write-Fail '未找到 Microsoft Edge；登录窗口需要 Edge。'
        if (-not $wasRunning) {
            $null = Stop-ServiceProcess
        }
        return
    }
    try {
        $null = Invoke-Admin -Method Post -Path '/admin/auth/login' -TimeoutSeconds 5
        Write-Step '请在弹出的 Edge 窗口中完成登录（最多等待 190 秒）...'
        $deadline = (Get-Date).AddSeconds(190)
        $last = $null
        while ((Get-Date) -lt $deadline) {
            Start-Sleep -Seconds 1
            try {
                $last = Invoke-Admin -Method Get -Path '/admin/auth/status' -TimeoutSeconds 3
            } catch {
                continue
            }
            if ([string]$last.state -ne 'logging_in') {
                break
            }
        }
        if ($last -and [string]$last.state -eq 'valid') {
            Write-Step '认证有效。'
        } elseif ($last) {
            Write-Fail ([string]$last.label + '（' + [string]$last.error + '）')
        } else {
            Write-Fail '无法读取认证状态。'
        }
    } catch {
        Write-Fail ('无法触发登录：' + $_.Exception.Message)
    }
    if (-not $wasRunning) {
        Write-Step '登录流程结束，正在停止临时启动的服务...'
        $null = Stop-ServiceProcess
    }
}

function Show-Status {
    $state = Get-ServiceState
    $auth = Get-AuthState
    $deployed = ((Test-Path -LiteralPath $venvPython) -and (Test-VenvDependencies))
    Write-Host '=========================================='
    Write-Host '   Chat2API 工作台'
    Write-Host ('   服务    : ' + (Get-ServiceStateLabel $state))
    Write-Host ('   地址    : http://' + $bindHost + ':' + $port + '/v1')
    Write-Host ('   上游    : ' + $upstream)
    Write-Host ('   认证    : ' + $auth.Label)
    if ($deployed) {
        Write-Host '   部署    : 已完成'
    } else {
        Write-Host '   部署    : 未完成（先双击 部署.bat）'
    }
    Write-Host '=========================================='
}

function Show-Models {
    if ((Get-ServiceState) -ne 'Running') {
        Write-Fail '服务未运行；请先启动。'
        return $false
    }
    $headers = @{}
    if ($localApiKey) {
        $headers['Authorization'] = 'Bearer ' + $localApiKey
    }
    try {
        $response = Invoke-RestMethod -Uri ((Get-LocalBaseUrl) + '/v1/models') -Headers $headers -TimeoutSec 30 -ErrorAction Stop
    } catch {
        Write-Fail ('获取模型列表失败：' + $_.Exception.Message)
        return $false
    }
    $models = @()
    if ($response.PSObject.Properties['data']) {
        $models = @($response.data)
    }
    if ($models.Count -eq 0) {
        Write-Step '没有可用模型。'
        return $true
    }
    Write-Step ('模型列表（' + $models.Count + ' 个）：')
    foreach ($model in $models) {
        if ($model.PSObject.Properties['id']) {
            $id = [string]$model.id
            if ($id) {
                Write-Host ('  - ' + $id)
            } else {
                Write-Host ('  - ' + ($model | ConvertTo-Json -Compress))
            }
        } else {
            Write-Host ('  - ' + ($model | ConvertTo-Json -Compress))
        }
    }
    return $true
}

function Show-Workbench {
    while ($true) {
        Clear-Workbench
        Show-Status
        Write-Host '   [1] 启动服务'
        Write-Host '   [2] 停止服务'
        Write-Host '   [3] 刷新状态'
        Write-Host '   [4] 重新登录'
        Write-Host '   [5] 查看模型列表'
        Write-Host '   [6] 查看最近日志'
        Write-Host '   [0] 退出工作台（不停止服务）'
        Write-Host '=========================================='
        $choice = Read-Host '请选择'
        switch ($choice) {
            '0' { return }
            '1' { $null = Start-ServiceProcess; $null = Read-Host '按回车继续' }
            '2' { $null = Stop-ServiceProcess; $null = Read-Host '按回车继续' }
            '3' { }
            '4' { Invoke-WorkbenchLogin; $null = Read-Host '按回车继续' }
            '5' {
                $null = Show-Models
                $null = Read-Host '按回车继续'
            }
            '6' {
                if (Test-Path -LiteralPath $serviceLogPath) {
                    Get-Content -LiteralPath $serviceLogPath -Tail 20 -Encoding UTF8
                } else {
                    Write-Step '暂无日志。'
                }
                $null = Read-Host '按回车继续'
            }
        }
    }
}

try {
    if (-not $Mode) {
        Write-Fail '请通过 部署.bat 或 使用.bat 运行；不要直接运行 launcher.ps1。'
        exit 1
    }
    if (-not (Test-Path -LiteralPath $serviceScript)) {
        Write-Fail '缺少 chat2api\chat2api.py；请重新解压完整的部署包。'
        exit 1
    }

    Write-Step '检查 Python...'
    $python = Find-Python
    if (-not $python) {
        Write-Fail '未找到 Python 3.10 或更新版本。'
        Write-Host '请安装 Python 3.11 或更新版本，安装时勾选 “Add python.exe to PATH”。'
        Write-Host '下载：https://www.python.org/downloads/windows/'
        exit 1
    }
    Write-Step ('Python ' + $python.Version + ' 可用。')

    $config = Read-Config
    $upstream = Get-ConfigEntry $config 'UPSTREAM_URL' ''
    if ($Mode -eq 'Deploy') {
        if (-not $upstream) {
            if ($CheckOnly) {
                Write-Warn 'UPSTREAM_URL 尚未设置；正式部署时会询问上游地址。'
            } else {
                $defaultUpstream = 'https://chat.genai.um.edu.mo'
                $entered = Read-Host ('请输入 Open WebUI 上游地址（直接回车使用 ' + $defaultUpstream + '）')
                if (-not $entered) {
                    $entered = $defaultUpstream
                }
                $upstream = Resolve-UpstreamUrl $entered
                Set-ConfigEntry 'UPSTREAM_URL' $upstream
                Write-Step ('已保存上游地址到 ' + $configPath)
            }
        } else {
            $upstream = Resolve-UpstreamUrl $upstream
            Write-Step ('当前上游：' + $upstream)
        }
    } else {
        if (-not $upstream) {
            throw '尚未配置上游地址。请先双击 部署.bat 完成部署。'
        }
        $upstream = Resolve-UpstreamUrl $upstream
    }

    $bindHost = Get-ConfigEntry $config 'HOST' '127.0.0.1'
    $portText = Get-ConfigEntry $config 'PORT' '8000'
    $port = 0
    if (-not [int]::TryParse($portText, [ref]$port) -or $port -lt 1 -or $port -gt 65535) {
        throw ('PORT 不是合法端口：' + $portText)
    }
    $clearProxy = Get-ConfigEntry $config 'CLEAR_PROXY' '0'
    $allowedOrigins = Get-ConfigEntry $config 'ALLOWED_ORIGINS' ''
    $useApiKey = Get-ConfigEntry $config 'USE_API_KEY' '0'
    $localApiKey = Get-ConfigEntry $config 'LOCAL_API_KEY' ''
    $isLoopback = ($bindHost -eq '127.0.0.1' -or $bindHost -eq 'localhost' -or $bindHost -eq '::1')
    if (-not $isLoopback -and -not $localApiKey) {
        throw 'HOST 不是本机回环地址时必须设置 LOCAL_API_KEY，否则 chat2api 会拒绝启动。'
    }

    $edge = Find-Edge
    if (-not $edge) {
        Write-Warn '未找到 Microsoft Edge。登录窗口需要 Edge；请先安装 Edge。'
    }

    $portInUse = Test-PortInUse $port

    if ($CheckOnly) {
        Write-Step ('模式：' + $Mode)
        if ($upstream) {
            Write-Step ('上游：' + $upstream)
        } else {
            Write-Warn '上游：尚未设置（正式部署会询问）'
        }
        Write-Step ('监听：' + $bindHost + ':' + $port)
        Write-Step ('Python：' + $python.Version + '（' + $python.Exe + '）')
        if ($edge) {
            Write-Step ('Edge：' + $edge)
        } else {
            Write-Step 'Edge：未找到'
        }
        Write-Step ('配置：' + $configPath)
        Write-Step ('服务脚本：' + $serviceScript)
        if (Test-Path -LiteralPath $venvPython) {
            Write-Step '.venv：已存在'
            if (Test-VenvDependencies) {
                Write-Step '依赖：已安装'
            } else {
                Write-Step '依赖：缺失'
            }
        } else {
            Write-Step '.venv：尚未创建'
        }
        if ($Mode -eq 'Start') {
            Write-Step ('服务：' + (Get-ServiceStateLabel (Get-ServiceState)))
        }
        if ($portInUse) {
            Write-Warn ('端口 ' + $port + ' 已被占用')
        } else {
            Write-Step ('端口：' + $port + ' 可用')
        }
        exit 0
    }

    if ($Mode -eq 'Deploy') {
        if ($portInUse) {
            Write-Warn ('端口 ' + $port + ' 已被占用；使用时需要先释放该端口或修改 config.txt 的 PORT。')
        }
        if (-not (Test-Path -LiteralPath $venvPython)) {
            Write-Step '创建本地 Python 环境 .venv ...'
            & $python.Exe @($python.Prefix + @('-m', 'venv', $venvDir))
            if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $venvPython)) {
                throw '创建 .venv 失败。请确认 Python 安装完整，或删除 .venv 后重试。'
            }
        }
        if (-not (Test-VenvDependencies)) {
            Write-Step '安装依赖 requests 与 playwright（需要联网，约几十 MB）...'
            & $venvPython -m pip install --disable-pip-version-check -r $requirementsPath
            if ($LASTEXITCODE -ne 0) {
                throw '依赖安装失败。请检查网络后重新运行；如仍失败，删除 .venv 再试。'
            }
            if (-not (Test-VenvDependencies)) {
                throw '依赖安装后仍无法导入。请删除 .venv 后重新运行。'
            }
        }
        Write-Host ''
        Write-Host '============================================================'
        Write-Host ' 部署完成。'
        Write-Host (' 上游：' + $upstream)
        Write-Host (' 地址：http://' + $bindHost + ':' + $port + '/v1')
        Write-Host ' 双击 使用.bat 打开工作台；首次启动会打开 Edge 登录。'
        Write-Host '============================================================'
        Write-Host ''
        exit 0
    }

    if (-not (Test-Path -LiteralPath $venvPython)) {
        throw '尚未创建 .venv。请先双击 部署.bat 完成部署。'
    }
    if (-not (Test-VenvDependencies)) {
        throw '依赖缺失。请先双击 部署.bat 完成部署。'
    }

    if ($Action -eq 'Start') {
        if (Start-ServiceProcess) { exit 0 }
        exit 1
    }
    if ($Action -eq 'Stop') {
        if (Stop-ServiceProcess) { exit 0 }
        exit 1
    }
    if ($Action -eq 'Status') {
        Show-Status
        exit 0
    }
    if ($Action -eq 'Login') {
        Invoke-WorkbenchLogin
        exit 0
    }
    if ($Action -eq 'Models') {
        if (Show-Models) { exit 0 }
        exit 1
    }
    if ($Action -eq 'Logs') {
        if (Test-Path -LiteralPath $serviceLogPath) {
            Get-Content -LiteralPath $serviceLogPath -Tail 20 -Encoding UTF8
            exit 0
        }
        Write-Step '暂无日志。'
        exit 0
    }

    Show-Workbench
    exit 0
} catch {
    Write-Fail $_.Exception.Message
    exit 1
}
